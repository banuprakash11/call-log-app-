package com.example.calllogapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
